# 🥇 Gold Super Bot v4.0 — Railway Deployment

## Setup Steps

### Step 1 — Config
Open `main.py` and set:
```python
"discord_webhook": "YOUR_DISCORD_WEBHOOK_URL"
"anthropic_api_key": "YOUR_KEY"  # optional
```

### Step 2 — GitHub
1. Go to github.com → New Repository → name: `gold-bot`
2. Upload all these files

### Step 3 — Railway
1. Go to railway.app → Login with GitHub
2. New Project → Deploy from GitHub repo
3. Select your `gold-bot` repo
4. Done! Bot starts automatically ✅

## Files
- `main.py` — The bot
- `requirements.txt` — Libraries
- `Procfile` — Run command
- `railway.json` — Railway config
